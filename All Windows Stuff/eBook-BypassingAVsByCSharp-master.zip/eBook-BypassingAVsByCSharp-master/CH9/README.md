

Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 9 : Transferring Backdoor Payload by Wireless Traffic (BSSID)

Related Videos :

Video 1 C# Code : https://youtu.be/W0dJGln3tls

Video 2 Script Code : https://www.youtube.com/watch?v=i6Y5BmJXWko

C# Source Code : https://github.com/DamonMohammadbagher/NativePayload_BSSID

Script Code : https://github.com/DamonMohammadbagher/NativePayload_BSSID/tree/master/Chapter%209%20-%20Transferring%20Backdoor%20Payload%20by%20Wireless%20Traffic%20-BSSID

Related Article :

link 1 : https://www.linkedin.com/pulse/transferring-backdoor-payloads-bssid-wireless-traffic-mohammadbagher/

link 2 : https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bssid-by-wireless-traffic-damon-mohammadbagher

Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
