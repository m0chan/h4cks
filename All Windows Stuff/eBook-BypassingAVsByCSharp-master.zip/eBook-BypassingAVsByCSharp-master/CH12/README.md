Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 12 : Simple way for Data Exfiltration via HTTP (PART1)

Chapter 12 : Simple way for Data Exfiltration via HTTP (PART2)

Related Videos :

Video [1] , Shell Script (server/client side) : https://www.youtube.com/watch?v=vjhubCYFP4c

Video [2] , C# code (client side) : https://www.youtube.com/watch?v=7MCOko-qy0c



C# Source Code : https://github.com/DamonMohammadbagher/NativePayload_HTTP/blob/master/Chapter%2012:%20Simple%20way%20for%20Data%20Exfiltration%20via%20HTTP/NativePayload_HTTP.cs

Script Code : https://github.com/DamonMohammadbagher/NativePayload_HTTP/blob/master/Chapter%2012:%20Simple%20way%20for%20Data%20Exfiltration%20via%20HTTP/NativePayload_HTTP.sh

Related Article :

link 1 : 

link 2 : 

Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
