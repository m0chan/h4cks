

Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 11 : Hiding Payloads via BMP Image Pixels (PART1)

Chapter 11 : Hiding Payloads via BMP Image Pixels (PART2)

Related Videos :

Video 1 Script and C# Code : https://www.youtube.com/watch?v=D5tfh23vIOQ

Video 2 (Chat Mode) Script Code  : https://www.youtube.com/watch?v=2n6ZLbJxlkw


C# Source Code : https://github.com/DamonMohammadbagher/NativePayload_Image

Script Code : https://github.com/DamonMohammadbagher/NativePayload_Image/tree/master/Chapter%2011%20-%20Hiding%20Payloads%20via%20BMP%20Image%20Pixels


Related Article :

link 1 : https://www.linkedin.com/pulse/transferring-backdoor-payloads-bmp-image-pixels-damon-mohammadbagher/

link 2 : https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bmp-image-pixels-damon-mohammadbagher

Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .

