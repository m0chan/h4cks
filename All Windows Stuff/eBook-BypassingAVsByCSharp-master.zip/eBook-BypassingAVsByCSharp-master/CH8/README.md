Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 8 : Transferring Backdoor Payloads by ARP Traffic 

Related Videos : 

C# Code : 

Video 1 C# Code : https://youtu.be/qDLicXj7Vuk

Video 2 Script Code : https://www.youtube.com/watch?v=O-llNZ9S8Mo

C# Source Code : https://github.com/DamonMohammadbagher/NativePayload_ARP

Script Code  :  https://github.com/DamonMohammadbagher/NativePayload_ARP/tree/master/Chapter%208%20-%20Transferring%20Backdoor%20Payloads%20by%20ARP%20Traffic



Related Article : 

link 1 :  https://www.linkedin.com/pulse/transfer-backdoor-payloads-arp-traffic-bypassing-avs-mohammadbagher/

link 2 : https://www.peerlyst.com/posts/transfer-backdoor-payloads-by-arp-traffic-and-bypassing-avs-damon-mohammadbagher



Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
