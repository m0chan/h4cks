#  eBook "Bypassing AVS by C#.NET Programming" (Free Chapters only)
Author :Damon Mohammadbagher

I want to share Chapters for my eBook before Publish it so i will share these , "chapter by chapter" via simple PDF/Code/Video files.

Chapters :

    Chapter 1 : Creating Simple Backdoor Payload by C#.NET
    Chapter 2 : Making Encrypted Meterpreter Payload by C#.NET
    Chapter 3 : DATA Transferring / Downloading Method by DNS Traffic (PTR Records)
    Chapter 4 : DATA Transferring Technique by DNS Traffic (A Records)
    Chapter 5 : Exfiltration and Uploading DATA by DNS Traffic (PTR Records)
    Chapter 6 : DATA Transferring Technique by DNS Traffic (AAAA Records)
    Chapter 7 : Exfiltration and Uploading DATA by DNS Traffic (IPv6 AAAA/PTR Queries)
    Chapter 8 : Transferring Backdoor Payloads by ARP Traffic
    Chapter 9 : Transferring Backdoor Payload by Wireless Traffic (BSSID)
    Chapter 10 : Transferring Payload via ICMPv4 Traffic by TTL
    Chapter 11 : Hiding Payloads via BMP Image Pixels 
    Chapter 12 : Simple way for Data Exfiltration via HTTP
    
Important Point about this eBook and these Chapters : These Chapters are some “Free” Parts of my Course so Please don't Ask me about Full Chapters/Codes and Videos.

     Video , eBook: Bypassing AVS by C# Programming 2016-2018

     this is my Security Codes/Articles/Chapters from 2016 to 2018 for this "eBook" ;)

     https://www.youtube.com/watch?v=zdF5MCTudXI


Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .

(some AVs will Dump/Upload your Codes/Exe to Their Servers for Analysis)


    
