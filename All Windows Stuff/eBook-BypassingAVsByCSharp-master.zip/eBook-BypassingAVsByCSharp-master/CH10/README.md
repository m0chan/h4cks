
Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 10 : Transferring Payload via ICMPv4 Traffic by TTL

Related Videos :

Video 1  : 

Video 2  : 

C# Source Code (v1.0): https://github.com/DamonMohammadbagher/NativePayload_ICMP

C# Source Code  (v2.0):  https://github.com/DamonMohammadbagher/NativePayload_ICMP/blob/master/Chapter%2010%20-%20Transferring%20Payload%20via%20ICMPv4%20Traffic%20by%20TTL

Script Code : https://github.com/DamonMohammadbagher/NativePayload_ICMP/tree/master/Chapter%2010%20-%20Transferring%20Payload%20via%20ICMPv4%20Traffic%20by%20TTL

Related Article :

link 1 : https://www.peerlyst.com/posts/transfer-download-payload-by-icmpv4-traffic-via-ttl-damon-mohammadbagher


Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
