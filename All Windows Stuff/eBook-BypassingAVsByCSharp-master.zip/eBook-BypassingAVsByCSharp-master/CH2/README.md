

Bypassing Anti Viruses by C#.NET Programming

Part 1 (C#.NET Tricks and Techniques)

Chapter 2 : Making Encrypted Meterpreter Payload by C#.NET

Related Videos : https://youtu.be/j6pwSemHfTY


C# Source Code: https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp/tree/master/Ebook%20-%20Chapter%202%20-%20Making%20Encrypted%20Meterpreter%20Payload%20by%20C-Sharp.NET


Related Article : 
https://www.linkedin.com/pulse/bypass-all-anti-viruses-encrypted-payloads-c-damon-mohammadbagher/


Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
