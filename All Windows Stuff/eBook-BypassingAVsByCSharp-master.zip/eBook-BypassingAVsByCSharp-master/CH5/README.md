Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 5 : Exfiltration and Uploading DATA by DNS Traffic (PTR Records)

Related Videos : 

NativePayload_DNS2.cs Csharp Code : 

https://www.youtube.com/watch?v=AgDbcC9kgcg

NativePayload_DNS2.sh Script Code : 

https://www.youtube.com/watch?v=zKUg_0LC9fk


C# Source Code 1 : https://github.com/DamonMohammadbagher/NativePayload_DNS2

Script Code  :  https://github.com/DamonMohammadbagher/NativePayload_DNS2/tree/master/Chapter%204%20-%20DATA%20Transferring%20Technique%20by%20DNS%20Traffic%20-%20A%20Records


Related Article : 

link 1 :  https://www.linkedin.com/pulse/exfiltration-uploading-data-dns-traffic-ptr-records-mohammadbagher/

link 2 : https://www.peerlyst.com/posts/exfiltrationand-uploading-data-by-dns-traffic-ptr-records-damon-mohammadbagher



Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
