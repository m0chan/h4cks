Bypassing Anti Viruses by C#.NET Programming

Part 1 (C#.NET Tricks and Techniques)

Chapter 1 : Creating Simple Backdoor Payload by C#.NET

Related Videos :

Chapter 1 - Video [1] , Creating Simple Backdoor Payload by C#.NET : https://www.youtube.com/watch?v=pdMgQSTuN0M

Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .

