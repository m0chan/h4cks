Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 7 : Exfiltration and Uploading DATA by DNS Traffic (IPv6 AAAA/PTR Queries)

Related Videos : 

C# Code : 

https://www.youtube.com/watch?v=9jiry5b-oPo

Script Code :

https://www.youtube.com/watch?v=6Lj-2KkHqgA

C# Source Code 1 : https://github.com/DamonMohammadbagher/RedbudTree

Script Code  :  https://github.com/DamonMohammadbagher/NativePayload_IP6DNS/tree/master/Chapter%206%20-%20DATA%20Transferring%20Technique%20by%20DNS%20Traffic%20-%20AAAA%20Records



Related Article : 

link 1 :  

link 2 : 



Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
