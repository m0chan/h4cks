Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)

Chapter 6 : DATA Transferring Technique by DNS Traffic (AAAA Records)

Related Videos : 

NativePayload_IP6DNS.sh Script Code : 

https://www.youtube.com/watch?v=Ac651MbNJ_U


C# Source Code 1 : https://github.com/DamonMohammadbagher/NativePayload_IP6DNS

Script Code  :  https://github.com/DamonMohammadbagher/NativePayload_IP6DNS/tree/master/Chapter%206%20-%20DATA%20Transferring%20Technique%20by%20DNS%20Traffic%20-%20AAAA%20Records



Related Article : 

link 1 :  https://www.linkedin.com/pulse/transferring-backdoor-payloads-dns-aaaa-records-ipv6-mohammadbagher/

link 2 : https://www.peerlyst.com/posts/transferring-backdoor-payloads-by-dns-aaaa-records-and-ipv6-address-damon-mohammadbagher



Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .
