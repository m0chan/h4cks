# waybackSqliScanner
Gather urls from wayback machine then test each GET parameter for sql injection.

## Usage
```
python main.py example.com
```
